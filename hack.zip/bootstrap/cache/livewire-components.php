<?php return array (
  'admin.groupe.selection' => 'App\\Http\\Livewire\\Admin\\Groupe\\Selection',
  'admin.parametrage.hackaton' => 'App\\Http\\Livewire\\Admin\\Parametrage\\Hackaton',
  'admin.parametrage.niveau' => 'App\\Http\\Livewire\\Admin\\Parametrage\\Niveau',
  'admin.parametrage.preselection' => 'App\\Http\\Livewire\\Admin\\Parametrage\\Preselection',
  'admin.parametrage.repartition' => 'App\\Http\\Livewire\\Admin\\Parametrage\\Repartition',
  'admin.restauration.commande' => 'App\\Http\\Livewire\\Admin\\Restauration\\Commande',
  'admin.restauration.qrcode' => 'App\\Http\\Livewire\\Admin\\Restauration\\Qrcode',
  'admin.restauration.repas' => 'App\\Http\\Livewire\\Admin\\Restauration\\Repas',
  'admin.salle' => 'App\\Http\\Livewire\\Admin\\Salle',
  'participants.enregistrement' => 'App\\Http\\Livewire\\Participants\\Enregistrement',
  'participants.quiz' => 'App\\Http\\Livewire\\Participants\\Quiz',
  'participants.video' => 'App\\Http\\Livewire\\Participants\\Video',
);