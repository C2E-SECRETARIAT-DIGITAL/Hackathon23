<div>
    <div x-data="Tabsetup()">

        <form method="POST">
            <?php echo csrf_field(); ?>

            <div x-show="activeTab===0">

                <div class="tete">
                    <h1 class="titre">Inscription :</h1>
                    <p>Etape 1 </p>
                </div>

                <div class="champs">
                    <div class="groupe">
                        <h1 class="tchamp"> Êtes vous de l'ESATIC ?</h1>
                        <div class="gr" style="display: flex; justify-content: space-between">
                            <label for="yes">Oui</label>
                            <input type="radio" name="choix" id="yes" value="0" wire:model="ion" checked />
                            <label for="no">Non</label>
                            <input type="radio" name="choix" id="no" value="1" wire:model="ion" />
                        </div>

                        <p>
                        </p>

                    </div>
                </div>

            </div>

            <div x-show="activeTab===1">

                <div class="tete">
                    <h1 class="titre">Inscription :</h1>
                    <p>Vous devez consigner ici les informations </p>
                </div>
                <div class="champs">
                    <div class="groupe">
                        <h1 class="tchamp"> Information du groupe</h1>
                        <div class="gr">

                            <label for="niveau" id="level">Niveau *</label>
                            <select id="niveau" name="niveau" class="<?php $__errorArgs = ['niveau'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model='niveau' value="<?php echo e(old("niveau")); ?>">

                                <?php $__currentLoopData = $niveaux; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $niveau): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($niveau->id); ?>"><?php echo e($niveau->libelle); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>


                            <label for="">Nom de l'équipe (30 Caractères Max) * </label>
                            <input type="text" id="nomE" class="<?php $__errorArgs = ['nom_groupe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.defer='nom_groupe' value="<?php echo e(old("nom_groupe")); ?>" placeholder="Nom de l'équipe" minlength="3" maxlength="30">


                            

                        </div>
                    </div>
                    <div class="chef">
                        <h1 class="tchef">Chef de l'Equipe</h1>
                        <div class="info_chef">

                            <?php if($ion == 0): ?>
                            <label for="NumMat" class="Matr">Numéro Matricule</label>
                            <input type="text" id="NumMat" class="NumMat <?php $__errorArgs = ['matricule_chef'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.defer='matricule_chef' value="<?php echo e(old("matricule_chef")); ?>" placeholder="00-ESATIC0000AB" min="16" maxlength="16">
                            <?php endif; ?>

                            <label for="">Nom * </label>
                            <input type="text" class="nom <?php $__errorArgs = ['nom_chef'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.defer='nom_chef' value="<?php echo e(old("nom_chef")); ?>" placeholder="Nom">

                            <label for=""> Prénoms * </label>
                            <input type="text" class="Pr  <?php $__errorArgs = ['prenom_chef'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.defer='prenom_chef' value="<?php echo e(old("prenom_chef")); ?>" placeholder="Prenom">

                            <br>

                            <label for="">Genre</label>
                            <select class="genre" name="Genre <?php $__errorArgs = ['genre_chef'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.defer='genre_chef' value="<?php echo e(old("genre_chef")); ?>">
                                <option value="Masculin">Masculin</option>
                                <option value="Feminin">Féminin</option>
                            </select>

                            <label for="">Classe </label>
                            <select class="clax" name="Classe <?php $__errorArgs = ['classe_chef'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.defer='classe_chef' value="<?php echo e(old("classe_chef")); ?>">
                                <option value="">---------</option>
                                <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($classe->id); ?>"><?php echo e($classe->libelle); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>

                            <br>

                            <label for="">Email :</label>
                            <input type="email" class="email  <?php $__errorArgs = ['email_chef'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.defer='email_chef' value="<?php echo e(old("email_chef")); ?>" placeholder="sophie@example.com"> <br>


                        </div>
                    </div>
                </div>

            </div>
            <div x-show="activeTab===2">

                <div class="tete">
                    <?php if(!$errorEmail and !$errorMatricule ): ?>
                    <p class="titre_m">Vous devez consigner ici les informations </p>
                    <?php else: ?>
                    <p class="titre_m" style="color:red; font-weight:bolder">Les emails et les matricules doivent êtres uniques (rafraichissez la page svp!)</p>
                    <?php endif; ?>
                </div>
                <div class="champs">

                    <div class="chef">
                        <h1 class="tchef">Membre 2</h1>
                        <div class="info_chef">

                            <?php if($ion == 0): ?>
                            <label for="NumMat_m1" class="Matr">Numéro Matricule</label>
                            <input type="text" id="NumMat_m1" class="NumMat_m <?php $__errorArgs = ['matricule_m2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.defer='matricule_m2' value="<?php echo e(old("matricule_m2")); ?>" placeholder="00-ESATIC0000AB" min="16" maxlength="16">
                            <?php endif; ?>

                            <label for="">Nom * </label>
                            <input type="text" class="nom_m <?php $__errorArgs = ['nom_m2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.defer='nom_m2' value="<?php echo e(old("nom_m2")); ?>" placeholder="Nom">


                            <label for=""> Prénoms* </label>
                            <input type="text" class="Pr_m <?php $__errorArgs = ['prenom_m2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.defer='prenom_m2' value="<?php echo e(old("prenom_m2")); ?>" placeholder="Prenom">

                            <br>

                            <label for="">Genre</label>
                            <select class="genre_m <?php $__errorArgs = ['genre_m2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.defer='genre_m2' value="<?php echo e(old("genre_m2")); ?>">
                                <option value="Masculin">Masculin</option>
                                <option value="Feminin">Féminin</option>
                            </select>


                            <label for="">Classe </label>
                            <select class="clax_m  <?php $__errorArgs = ['classe_m2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.defer='classe_m2' value="<?php echo e(old("classe_m2")); ?>">
                                <option>---------</option>
                                <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($classe->id); ?>"><?php echo e($classe->libelle); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>

                            <br>

                            <div>
                                <label for="">Email :</label>
                                <input type="email" class="email_m  <?php $__errorArgs = ['email_m2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.defer='email_m2' value="<?php echo e(old("email_m2")); ?>" placeholder="sophie@example.com"> <br>


                            </div>
                        </div>
                    </div>

                    <div class="chef">
                        <h1 class="tchef">Membre 3</h1>
                        <div class="info_chef">

                            <?php if($ion == 0): ?>
                            <label for="NumMat_m2" class="Matr">Numéro Matricule</label>
                            <input type="text" id="NumMat_m2" class="NumMat_m <?php $__errorArgs = ['matricule_m3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.defer='matricule_m3' value="<?php echo e(old("matricule_m3")); ?>" placeholder="00-ESATIC0000AB" min="16" maxlength="16">
                            <?php endif; ?>

                            <label for="">Nom * </label>
                            <input type="text" class="nom_m <?php $__errorArgs = ['nom_m3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.defer='nom_m3' value="<?php echo e(old("nom_m3")); ?>" placeholder="Nom">


                            <label for=""> Prénoms* </label>
                            <input type="text" class="Pr_m <?php $__errorArgs = ['prenom_m3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.defer='prenom_m3' value="<?php echo e(old("prenom_m3")); ?>" placeholder="Prenom">

                            <br>

                            <label for="">Genre</label>
                            <select class="genre_m <?php $__errorArgs = ['genre_m3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.defer='genre_m3' value="<?php echo e(old("genre_m3")); ?>">
                                <option value="Masculin">Masculin</option>
                                <option value="Feminin">Féminin</option>
                            </select>


                            <label for="">Classe </label>
                            <select class="clax_m  <?php $__errorArgs = ['classe_m3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.defer='classe_m3' value="<?php echo e(old("classe_m3")); ?>">
                                <option>---------</option>
                                <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($classe->id); ?>"><?php echo e($classe->libelle); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>

                            <br>

                            <div>
                                <label for="">Email :</label>
                                <input type="email" class="email_m  <?php $__errorArgs = ['email_m3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.defer='email_m3' value="<?php echo e(old("email_m3")); ?>" placeholder="sophie@example.com"> <br>


                            </div>
                        </div>
                    </div>

                </div>

                <div class=" justify-center">

                    <?php if($errorEmail or $errorMatricule or count($errors) > 0 ): ?>
                    <span class="mx-4 text-xl text-red-500">
                        veuillez verifier vos informations
                    </span>
                    <?php endif; ?>

                    <button wire:click.prevent='createEquipe' class="px-6 py-3 my-1 mr-1 text-sm font-bold text-white uppercase transition-all duration-150 rounded shadow outline-none 
                        <?php if(!$errorEmail and !$errorMatricule and count($errors) == 0  ): ?>  bg-myblue <?php else: ?> bg-gray-500 <?php endif; ?> ease-linearbg-emerald-500  hover:shadow-lg focus:outline-none" type="submit">
                        Confirmer l'enregistrement
                    </button>
                </div>

            </div>

        </form>

        <div class="flex justify-center gap-4 p-2 border-t">
            <button class="px-4 py-2 text-sm font-bold uppercase border rounded-md cursor-pointer text-orange border-orange hover:bg-orange hover:text-white hover:shadow" @click="activeTab--" x-show="activeTab>0">
                Précédent
            </button>
            <button class="px-4 py-2 text-sm font-bold uppercase border rounded-md cursor-pointer border-orange text-orange hover:bg-orange hover:text-white hover:shadow" @click="activeTab++" x-show="activeTab<tabs.length">
                Suivant
            </button>
        </div>
    </div>
</div><?php /**PATH /home/scoppy48/Documents/WORKSPACE/C2E/Prototypes/Hackaton23/resources/views/livewire/participants/enregistrement.blade.php ENDPATH**/ ?>