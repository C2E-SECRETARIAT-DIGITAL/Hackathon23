<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Espace Restauration SDI')); ?>

        </h2>
     <?php $__env->endSlot(); ?>


    <div class="gap-4 px-6 py-12 md:grid md:grid-cols-6">

        <div class="col-span-2 ">

            <div class="px-6 py-6  justify-center flex-col text-xl text-center bg-white shadow-xl sm:rounded-lg">
                
                
                <span >
                    <?php echo e($qrcode); ?>

                </span>

                <span class="font-bold py-4 text-orange" >Code de restauration</span>
            </div>

        </div>

        <div class="col-span-4 py-6 text-center px-6">

            <?php if(Auth::user()->etudiant->is_chief()): ?>
            
                

                <?php if(!Auth::user()->etudiant->Commande()): ?>

                    <div class="col-span-2 py-6 px-6 ">
                        <p class="text-xl font-bold">
                            Enregistrement des commandes de collation de l'equipe
                        </p>
                    </div>

                    <form method="POST" action="<?php echo e(route('get.commande', null, false)); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="grid  md:grid-cols-6 gap-4">

                            <?php $__currentLoopData = Auth::user()->etudiant->getEquipe()->participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                                <div class=" col-span-2 text-right font-semibold">
                                    <?php echo e($participant->etudiant->nom); ?> <?php echo e($participant->etudiant->prenom); ?> 
                                </div>

                                <div class=" col-span-4 text-left">
                                    <div class="pt-0 mb-3">
                                        <select  name=<?php echo e('collation_etu'.$key.'_id'); ?> value="<?php echo e(old('collation_etu'.$key.'_id')); ?>"
                                                class="relative md:w-96 w-full px-12 py-2 text-sm text-gray-600 placeholder-gray-400 bg-white border-gray-400 rounded outline-none form-select focus:border-coolGray-400 focus:outline-none focus:ring-coolGray-100">
                                            <option value=""></option>
                                            
                                            <?php $__currentLoopData = $collations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($collation->id); ?>"> <?php echo e($collation->libelle); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        </select>
                                        <?php $__errorArgs = ['collation_etu'.$key.'_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-sm font-thin text-center text-red-600"><?php echo e($errors->first('collation_etu'.$key.'_id')); ?>  </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 


                            <div class=" md:col-span-6 flex justify-center">
                                <button 
                                    type="submit"
                                    class="px-6 py-3 mb-1 mr-1 text-sm font-bold text-white uppercase transition-all duration-150 rounded shadow outline-none ease-linearbg-emerald-500 bg-myblue hover:shadow-lg focus:outline-none" type="submit">
                                        Enregistrer 
                                </button>
                            </div>
                            

                        </div>
                    </form>

                <?php else: ?>

                    <div class="py-6">

                        <span>MERCI VOUS RECEVREZ TRES BIENTÔT VOTRE COMMANDE </span>

                        <?php $__currentLoopData = Auth::user()->etudiant->getEquipe()->participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             
                            <p class="text-xl py-4 font-bold">
                                <?php echo e($participant->etudiant->nom); ?> <?php echo e($participant->etudiant->prenom); ?> à commandé du 
                                <span class="text-orange"><?php echo e($participant->etudiant->Commande()->collation->libelle); ?></span>
                            </p>
                             
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    
                    
                <?php endif; ?>
                
                
            

            <?php else: ?>
            
                <img src=" <?php echo e(asset('images/app/secure.svg')); ?> " class="WineLogo">

            <?php endif; ?>

        </div>

    

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /home/scoppy48/Documents/WORKSPACE/C2E/Prototypes/Hackaton23/resources/views/participants/restauration.blade.php ENDPATH**/ ?>