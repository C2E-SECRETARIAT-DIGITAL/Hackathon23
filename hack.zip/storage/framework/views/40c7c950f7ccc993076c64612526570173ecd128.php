<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Espace SDI: Test de présélection')); ?>

        </h2>

     <?php $__env->endSlot(); ?>

    <div x-data="data()">

        <div x-show="!start" class="gap-4 px-6 py-12 md:grid md:grid-cols-6">

            <div class="col-span-2 "></div>

            <div class="col-span-2 ">

                <div class="px-4 py-6 text-xl bg-white shadow-xl sm:rounded-lg">
                    <?php if(Auth::user()->etudiant->getEquipe()->statut == 0): ?>

                        <?php if(Auth::user()->etudiant->getEquipe()->niveau->quiz_available == 1): ?>
                    
                            <?php if(Auth::user()->etudiant->getEquipe()->qsession->quiz->state == 1): ?>

                                <?php if(Auth::user()->etudiant->getEquipe()->qsession->state == 0 && Auth::user()->etudiant->getEquipe()->qsession->score == 0): ?>

                                    <p class="font-bold text-center text-md">
                                        Le quiz des préselections est ouvert !
                                    </p>
                                    <p class="text-center mt-4">
                                        Ce quiz est composé de <?php echo e(sizeof(Auth::user()->etudiant->getEquipe()->qsession->quiz->questions)); ?> questions. <br>
                                        <span class="text-red-600">>Vous disposez de 30 secondes par question</span> <br>
                                        <span class="text-red-600">>Les questions apparaissent une et une seule fois</span> <br>
                                        <span class="text-red-600">>Si vous rafraichissez ou quittez la page durant le test, seules les questions <br>
                                        auquelles vous avez répondues sont prises en compte et votre test prend fin.
                                        </span> <br>
                                        <span class="text-red-600">>Le quiz débute une fois que vous cliquez sur le bouton "COMMENCER LE TEST"</span> <br>
                                    </p>
                                    <div class="text-center mt-5">
                                        <button @click="start = true" onclick="begin()" class="px-6 py-3 mb-1 mr-1 text-sm font-bold text-white uppercase transition-all duration-150 rounded shadow outline-none ease-linearbg-emerald-500 bg-myblue hover:shadow-lg focus:outline-none">
                                            Commencer le test
                                        </button>
                                    </div>

                                <?php elseif(Auth::user()->etudiant->getEquipe()->qsession->state == 1 && Auth::user()->etudiant->getEquipe()->qsession->score > 0): ?>

                                    <p class="font-bold text-center text-md">
                                        Vous avez terminé le quiz. <br> Les résultats seront bientôt disponibles, veillez patienter !
                                    </p>

                                <?php endif; ?>
                            
                            <?php else: ?>
                            

                                <?php if(Auth::user()->etudiant->getEquipe()->qsession->state == 0): ?>

                                    <p class="font-bold text-center text-md">
                                        Les quizs sont fermés.
                                    </p>
                                    
                                <?php elseif(Auth::user()->etudiant->getEquipe()->qsession->state == 1 && Auth::user()->etudiant->getEquipe()->qsession->score > 0): ?>

                                    <p class="font-bold text-center text-md">
                                        Vous avez terminé le quiz. <br> Les résultats seront bientôt disponibles, veillez patienter !
                                    </p>

                                <?php elseif(Auth::user()->etudiant->getEquipe()->qsession->score < 0): ?>

                                    <img src=" <?php echo e(asset('images/app/lose.svg')); ?> " class="loseLogo">
                                    <p class="font-bold text-center text-red-600 text-md">
                                        Dommange, la prochaine fois sera la bonne !
                                    </p>

                                <?php endif; ?>

                            <?php endif; ?>

                        <?php endif; ?>

                    <?php else: ?>
                    <img src=" <?php echo e(asset('images/app/winner.svg')); ?> " class="winLogo">
                    <p class="font-bold text-green-600 text-center text-md">
                        Félicitations votre équipe est séléctionnez !!
                    </p>
                    <?php endif; ?>
                </div>
            </div>
        </div>


        <div x-show="start == true" class="py-6">

            <div class="mx-auto max-w-8xl sm:px-6 lg:px-8">

                <div class="overflow-hidden bg-white shadow-xl sm:rounded-lg">

                    <div class="w-full h-full">

                        <div class="bg-white">

                            <div class="w-full h-full ">

                                <div class="px-4 py-5 ">
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('participants.quiz')->html();
} elseif ($_instance->childHasBeenRendered('0fhyYHr')) {
    $componentId = $_instance->getRenderedChildComponentId('0fhyYHr');
    $componentTag = $_instance->getRenderedChildComponentTagName('0fhyYHr');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0fhyYHr');
} else {
    $response = \Livewire\Livewire::mount('participants.quiz');
    $html = $response->html();
    $_instance->logRenderedChild('0fhyYHr', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                </div>

                            </div>
                        </div>

                    </div>

                </div>

            </div>

        </div>


    </div>



     <?php $__env->slot('scripts', null, []); ?> 

        <script>
            function data() {
                return {
                    start: false,
                }
            }

            function begin() {
                Livewire.emit('openSession')
                var count = setInterval(function() {

                    var sec = parseInt(document.getElementById('counts').innerText)
                    const ind = parseInt(document.getElementById('ind').innerText)
                    const ques = parseInt(document.getElementById('ques').innerText)

                    sec -= 1

                    if (sec == -1) {
                        if (ind + 1 <= ques)
                            Livewire.emit('storeAndMove', 1)
                        else
                            Livewire.emit('storeAndExit')

                        sec = 31
                    }

                    if (sec < 10)
                        sec = "0" + String(sec)

                    document.getElementById('seconds').innerText = sec
                    document.getElementById('counts').innerText = sec

                }, 1000)
            }
        </script>

     <?php $__env->endSlot(); ?>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH /home/scoppy48/Documents/WORKSPACE/C2E/Prototypes/Hackaton23/resources/views/participants/preselection.blade.php ENDPATH**/ ?>