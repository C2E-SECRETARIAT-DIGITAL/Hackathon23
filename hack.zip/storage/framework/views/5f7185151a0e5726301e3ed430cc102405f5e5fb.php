<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/scoppy48/Documents/WORKSPACE/C2E/Prototypes/Hackaton23/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>