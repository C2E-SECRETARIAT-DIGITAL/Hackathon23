<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div class="py-6">
        <div class="mx-auto max-w-8xl sm:px-6 lg:px-8">
            <div class="overflow-hidden bg-white shadow-xl sm:rounded-lg">
                
                <div x-data="Tabsetup()" class="w-full h-full">
                    <ul class="flex items-center justify-center mt-2 mb-4">
                        <template x-for="(tab, index) in tabs" :key="index">
                            <li class="px-4 text-gray-500 border-b-8 cursor-pointer"
                                :class="activeTab===index ? 'text-orange border-orange' : '' " @click="activeTab = index"
                                x-text="tab"></li>
                        </template>
                    </ul>
            
                    <div class="w-full h-full bg-white">
                        <div x-show="activeTab===0" >
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.parametrage.hackaton')->html();
} elseif ($_instance->childHasBeenRendered('NCfh98f')) {
    $componentId = $_instance->getRenderedChildComponentId('NCfh98f');
    $componentTag = $_instance->getRenderedChildComponentTagName('NCfh98f');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NCfh98f');
} else {
    $response = \Livewire\Livewire::mount('admin.parametrage.hackaton');
    $html = $response->html();
    $_instance->logRenderedChild('NCfh98f', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                        <div x-show="activeTab===1" >
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.parametrage.niveau')->html();
} elseif ($_instance->childHasBeenRendered('Iz9RdqZ')) {
    $componentId = $_instance->getRenderedChildComponentId('Iz9RdqZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('Iz9RdqZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Iz9RdqZ');
} else {
    $response = \Livewire\Livewire::mount('admin.parametrage.niveau');
    $html = $response->html();
    $_instance->logRenderedChild('Iz9RdqZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                        <div x-show="activeTab===2" >
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.salle')->html();
} elseif ($_instance->childHasBeenRendered('nPvFZpL')) {
    $componentId = $_instance->getRenderedChildComponentId('nPvFZpL');
    $componentTag = $_instance->getRenderedChildComponentTagName('nPvFZpL');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nPvFZpL');
} else {
    $response = \Livewire\Livewire::mount('admin.salle');
    $html = $response->html();
    $_instance->logRenderedChild('nPvFZpL', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                        <div x-show="activeTab===3" >
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.parametrage.repartition')->html();
} elseif ($_instance->childHasBeenRendered('M3zfWGs')) {
    $componentId = $_instance->getRenderedChildComponentId('M3zfWGs');
    $componentTag = $_instance->getRenderedChildComponentTagName('M3zfWGs');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('M3zfWGs');
} else {
    $response = \Livewire\Livewire::mount('admin.parametrage.repartition');
    $html = $response->html();
    $_instance->logRenderedChild('M3zfWGs', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                        <div x-show="activeTab===4" >
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.parametrage.preselection')->html();
} elseif ($_instance->childHasBeenRendered('GVLglz5')) {
    $componentId = $_instance->getRenderedChildComponentId('GVLglz5');
    $componentTag = $_instance->getRenderedChildComponentTagName('GVLglz5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('GVLglz5');
} else {
    $response = \Livewire\Livewire::mount('admin.parametrage.preselection');
    $html = $response->html();
    $_instance->logRenderedChild('GVLglz5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                        <div x-show="activeTab===5" >
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.restauration.repas')->html();
} elseif ($_instance->childHasBeenRendered('Pd1TPke')) {
    $componentId = $_instance->getRenderedChildComponentId('Pd1TPke');
    $componentTag = $_instance->getRenderedChildComponentTagName('Pd1TPke');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Pd1TPke');
} else {
    $response = \Livewire\Livewire::mount('admin.restauration.repas');
    $html = $response->html();
    $_instance->logRenderedChild('Pd1TPke', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                        
                    </div>
                    
                    <div class="flex justify-center gap-4 p-2 border-t">
                        <button
                            class="px-4 py-2 text-sm font-bold uppercase border rounded-md cursor-pointer text-orange border-orange hover:bg-orange hover:text-white hover:shadow"
                            @click="activeTab--" x-show="activeTab>0"
                            >Précédent</button>
                        <button
                            class="px-4 py-2 text-sm font-bold uppercase border rounded-md cursor-pointer border-orange text-orange hover:bg-orange hover:text-white hover:shadow"
                            @click="activeTab++" x-show="activeTab<tabs.length-1"
                            >Suivant</button>
                    </div>
                </div>
                

            </div>
        </div>
    </div>


     <?php $__env->slot('scripts', null, []); ?> 
        <script>
            function Tabsetup() {
                return {
                activeTab: 0,
                tabs:['Hackaton', 'Niveaux', 'Salle', 'Repartition', 'Preselection', 'Restauration']
                
                };
            };
        </script>
     <?php $__env->endSlot(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH /home/scoppy48/Documents/WORKSPACE/C2E/Prototypes/Hackaton23/resources/views/Admin/parametrage.blade.php ENDPATH**/ ?>