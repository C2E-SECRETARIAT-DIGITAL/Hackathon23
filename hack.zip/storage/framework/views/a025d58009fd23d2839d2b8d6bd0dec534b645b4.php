
<img src="<?php echo e(asset('images/app/logoSDI-PhotoRoom.png')); ?>" class="logoS w-32 h-20">
<?php /**PATH /home/scoppy48/Documents/WORKSPACE/C2E/Prototypes/Hackaton23/resources/views/vendor/jetstream/components/application-mark.blade.php ENDPATH**/ ?>