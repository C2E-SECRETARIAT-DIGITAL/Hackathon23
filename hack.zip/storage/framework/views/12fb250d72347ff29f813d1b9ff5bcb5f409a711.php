<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Hackaton 2022</title>
        <link rel="icon" href="<?php echo e(asset('images/app/logoSDI-PhotoRoom.png')); ?>" type="image/icon type">
        
        <link rel="stylesheet" href="<?php echo e(asset('css/inscription.css')); ?>" />

        <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
        
        <?php echo \Livewire\Livewire::styles(); ?>

        <!-- Scripts -->
        <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>

    </head>
    <body >
        
        <div class="navbar">
            <div class="logo">
                <a href="<?php echo e(route('welcome',  null, false)); ?>"><img src="<?php echo e(asset('images/app/logoHackathon-PhotoRoom.png')); ?>" class="logoH"></a>
            </div>
            <div class="nav">
                <ul>
                    <li><a href="<?php echo e(route('welcome',  null, false)); ?>">acceuil</a></li>
                    <li><a href="<?php echo e(route('login',  null, false)); ?>">connexion</a></li>
                </ul>
            </div>
        </div>
        <div class="content">
            
            <div x-data="Tabsetup()">
                        
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('participants.enregistrement')->html();
} elseif ($_instance->childHasBeenRendered('yQjqQnv')) {
    $componentId = $_instance->getRenderedChildComponentId('yQjqQnv');
    $componentTag = $_instance->getRenderedChildComponentTagName('yQjqQnv');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('yQjqQnv');
} else {
    $response = \Livewire\Livewire::mount('participants.enregistrement');
    $html = $response->html();
    $_instance->logRenderedChild('yQjqQnv', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                
            </div>
        </div>


        <script>
            function Tabsetup() {
                return {
                activeTab: 0,
                tabs:['groupe', 'participants', ]
                
                };
            };
        </script>
        <?php echo \Livewire\Livewire::scripts(); ?>

    </body>
</html>
<?php /**PATH /home/scoppy48/Documents/WORKSPACE/C2E/Prototypes/Hackaton23/resources/views/participants/inscription.blade.php ENDPATH**/ ?>