<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>C2E | HACKATHON</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
  
  <link rel="stylesheet" media="screen" href="<?php echo e(asset('css/particles1.css')); ?>">
  <link rel="stylesheet" media="screen" href="<?php echo e(asset('css/acceuil.css')); ?>">
  <link rel="icon" href="<?php echo e(asset('images/app/logoSDI-PhotoRoom.png')); ?>" type="image/icon type">
  
</head>
<body>

    <div class="couv"   style="position:fixed;">
        <div class="couv" >
            <div class="logo">
                <img src=" <?php echo e(asset('images/app/logoEsatic-PhotoRoom.png')); ?> " class="logoE">
                <img src=" <?php echo e(asset('images/app/logoC2E-PhotoRoom.png')); ?> " class="logoC">
            </div>
            <div class="content">
                <div class="imag">
                    <img src="<?php echo e(asset('images/app/logoSDI-PhotoRoom.png')); ?>" class="logoS">
                    <img src="<?php echo e(asset('images/app/logoHackathon-PhotoRoom.png')); ?>" class="logoH">
                </div>
               
                <div class="champs">
                    <?php if(Route::has('login')): ?>
                    
                        <?php if(auth()->guard()->check()): ?>

                            <?php if($statut): ?>
                                <div class="b1">
                                    <a href="<?php echo e(route('Participants.inscription',  null, false)); ?>"><button type="button">  INSCRIPTION</button></a>
                                </div> 
                            <?php else: ?>
                                <div class="b1">
                                    <a href="<?php echo e(route('finPreselection',  null, false)); ?>"><button type="button">  INSCRIPTION</button></a>
                                </div>
                            <?php endif; ?>
                           
                            <div class="b2">
                                <a href="<?php echo e(route('dashboard',  null, false)); ?>"><button type="button"> <span></span> MON PROFIL</button></a>
                            </div>
                            
                        <?php else: ?>
                            
                            <?php if($statut): ?>
                                <div class="b1">
                                    <a href="<?php echo e(route('Participants.inscription',  null, false)); ?>"><button type="button">  INSCRIPTION</button></a>
                                </div>
                            <?php else: ?>
                                <div class="b1">
                                    <a href="<?php echo e(route('finPreselection',  null, false)); ?>"><button type="button">  INSCRIPTION</button></a>
                                </div>
                            
                            <?php endif; ?>

                            <div class="b2">
                                <a href="<?php echo e(route('login',  null, false)); ?>"><button type="button"><span></span> CONNEXION</button></a>  
                            </div> 
                        <?php endif; ?>
                    
                    <?php endif; ?>
    
                </div>
            </div>
        </div>
    </div>

<!-- particles.js container -->
<div id="particles-js">
    
    
</div>

<!-- scripts -->

<script src="<?php echo e(asset('js/particles.js')); ?>" ></script>
<script src="<?php echo e(asset('js/app-particles1.js')); ?>" ></script>


</body>
</html><?php /**PATH /home/scoppy48/Documents/WORKSPACE/C2E/Prototypes/Hackaton23/resources/views/acceuil.blade.php ENDPATH**/ ?>