<div>
    <div class="col-span-6 w-full">
        <div class="md:grid md:grid-cols-6">
            <div class="col-span-6">
                <div class="flex flex-col">
                    <div class="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div class="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
                            <div class="overflow-hidden border-b border-gray-200 shadow sm:rounded-lg">

                                <table class="min-w-full divide-y table-auto  divide-gray-200">

                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th scope="col" class="text-center px-6 py-3 text-xs font-bold tracking-wider text-left text-gray-500 uppercase">
                                                <?php echo e($quiz->questions[$current_index]->content); ?>

                                            </th>
                                        </tr>

                                    </thead>

                                    <tbody class="bg-white divide-y divide-gray-200">
                                        <?php $__currentLoopData = $quiz->questions[$current_index]->responses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $response): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="flex items-center">
                                                    <div class="ml-4">
                                                        <div class="font-bold text-gray-900 text-md">
                                                            <input wire:model="sponses.<?php echo e($response->id); ?>" type="checkbox" name="r<?php echo e($response->id); ?>" id="r<?php echo e($response->id); ?>" checked />
                                                        </div>
                                                    </div>
                                                    <div class="ml-4">
                                                        <div class="font-bold text-gray-900 text-md">
                                                            <label for="r<?php echo e($response->id); ?>">
                                                                <?php echo e($response->content); ?>

                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="mt-2">
        <p>Questions: <span id="ind"><?php echo e($current_index + 1); ?></span> / <span id="ques"><?php echo e(sizeof($quiz->questions)); ?></span> </p>
        <div class="mt-2 font-bold text-red-600">
            Temps restant:<span id="seconds"></span>
        </div>
    </div>

    <div class="flex justify-center gap-4 p-2 border-t">
        <?php if($next): ?>
        <button class="px-4 py-2 text-sm font-bold uppercase border rounded-md cursor-pointer bg-orange text-white hover:shadow" onclick="resetTimer()" wire:click="storeAndMove(1)">Suivant</button>
        <?php else: ?>
        <button class="px-4 py-2 text-sm font-bold uppercase border rounded-md cursor-pointer bg-red-600 text-white hover:shadow" wire:click="storeAndExit()">Terminer</button>
        <?php endif; ?>
    </div>

</div>

<span id="counts" style="display: none;">31</span>

<script>
    function resetTimer() {
        document.getElementById("counts").innerText = 31
    }
</script><?php /**PATH /home/scoppy48/Documents/WORKSPACE/C2E/Prototypes/Hackaton23/resources/views/livewire/participants/quiz.blade.php ENDPATH**/ ?>