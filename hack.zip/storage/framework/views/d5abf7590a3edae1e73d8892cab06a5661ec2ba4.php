<a href="/">
    
    <img src="<?php echo e(asset('images/app/logoSDI-PhotoRoom.png')); ?>" class="logoS w-48 h-36">
</a>
<?php /**PATH /home/scoppy48/Documents/WORKSPACE/C2E/Prototypes/Hackaton23/resources/views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>