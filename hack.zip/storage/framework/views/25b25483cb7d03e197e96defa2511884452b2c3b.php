<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <?php if($message = Session::get('danger')): ?>
        <div class="flex justify-center py-4">
            
            <div
                class="flex w-full max-w-sm overflow-hidden bg-white rounded-lg shadow-md dark:bg-gray-800">
                <div class="flex items-center justify-center w-12 bg-red-500">
                    <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                </div>
        
                <div class="px-4 py-2 -mx-3">
                    <div class="mx-3">
                        <span class="font-bold text-red-500 dark:text-red-400"
                        >SDI - Hackathon </span
                        >
                        <p class="text-xs text-gray-600 md:text-sm dark:text-gray-200">
                        <?php echo e($message); ?>

                        </p>
                    </div>
                </div>
            </div>
            
        </div>
    <?php endif; ?>

    <div class="py-4">
        <div class="max-w-8xl mx-auto sm:px-6 lg:px-2">
            <div class="bg-white overflow-hidden shadow-md py-4 px-4 sm:rounded-lg">
                
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.groupe.selection')->html();
} elseif ($_instance->childHasBeenRendered('jHjI2ms')) {
    $componentId = $_instance->getRenderedChildComponentId('jHjI2ms');
    $componentTag = $_instance->getRenderedChildComponentTagName('jHjI2ms');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jHjI2ms');
} else {
    $response = \Livewire\Livewire::mount('admin.groupe.selection');
    $html = $response->html();
    $_instance->logRenderedChild('jHjI2ms', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH /home/scoppy48/Documents/WORKSPACE/C2E/Prototypes/Hackaton23/resources/views/Admin/selection.blade.php ENDPATH**/ ?>